rails g scaffold anime name:string details:text

rails g model anime name:string details:text

rails g scaffold movie name:string details:text

rails g model movie name:string details:text

rails g scaffold television_show name:string details:text

rails g model television_show name:string details:text


rails db:migrate