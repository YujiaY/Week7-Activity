require 'test_helper'

class TelevisionShowTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
