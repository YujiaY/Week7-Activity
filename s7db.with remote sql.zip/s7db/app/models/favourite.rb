class Favourite < ApplicationRecord
end
