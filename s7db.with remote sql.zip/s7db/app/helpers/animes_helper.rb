module AnimesHelper
end
