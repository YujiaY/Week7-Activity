module FavouritesHelper
end
